.. :changelog:

History
-------

cmake-python-distributions was initially developed in September 2016 by
Jean-Christophe Fillion-Robin to facilitate the distribution of project using
`scikit-build <http://scikit-build.readthedocs.io/>`_ and depending on CMake.
