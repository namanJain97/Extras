Security Policy
===============

Supported Versions
------------------

Only recent version of pyppmd are currently being supported with security updates.

+---------+--------------------+
| Version | Status             |
+=========+====================+
| 0.18.x  | Development        |
+---------+--------------------+
| < 0.18  | not supported      |
+---------+--------------------+

Reporting a Vulnerability
-------------------------

Please disclose security vulnerabilities privately at miurahr@linux.com
