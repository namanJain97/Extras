version_info = (0, 10, 2)
__version__ = ".".join(map(str, version_info))
